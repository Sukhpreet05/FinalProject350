<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Store</title>
  <link rel=stylesheet type="text/css" href="./styles/style-main.css">
  <script src="./scripts/menu-script.js"></script>
  <?php 
  require "./scripts/product_model.php";
  ?>
  </head>
<body onload="init()">
	<div id="page-wrap">
		<nav>
			<ul>
  				<li id="icon"><a href="index.php"><img src="./images/atom-logo.png" alt="logo"></a></li>
				<a href="checkout.html"><li id="cart"></li></a>
  				<li class="menu-item"><a href="contact.html">Contact</a></li>
  				<li class="menu-item"><a href="store.php">Store</a></li>
  				<li class="menu-item"><a href="about.html">About</a></li>
  				<li id="underline"></li>
			</ul>
		</nav>
		
		<div class="header-banner-store">
			<div class="banner-text-heading-store">New fall devices have arrived.</div>
		</div>
		
		<div id="store-text">Appropriately revolutionize robust scenarios without dynamic strategic theme areas. Objectively<br>
   					orchestrate ethical convergance after out-of-the-box niches.</div>
   		
   			<div class="dropdown">
                <li> <button class="dropbtn">Dropdown</button> </li>
                <div id="myDropdown" class="dropdown-content">

               </div>
            </div>
   
   		
   		<div class="feature">
   			<div id = "cata">
		  <script src="./scripts/catalogBuilder.js"></script>
		  </div>
  		</div> <!-- end of .feature -->
		<div class=clearboth></div>

   		
   		<div class="footer-store"> 
   			<ul class="footer-list">
				<li id="follow">Follow Us:</li>
				<li class="social"><a href="#facebook"><img src="images/icons/icon_facebook.png" alt="facebook"></a>
				<li class="social"><a href="#twitter"><img src="images/icons/icon_twitter.png" alt="twitter"></a>
				<li class="social"><a href="#google"><img src="images/icons/icon_google.png" alt="google"></a>
				<li class="footer-menu-item"><a href="contact.html">Contact</a></li>
				<li class="footer-menu-item"><a href="store.php">Store</a>
				<li class="footer-menu-item"><a href="about.html">About</a>
			</ul>
			<p>&#x40; 2016 Atom Ltd. All Rights Reserved.
   		
   		</div> <!-- end of .footer -->
	
	</div> <!-- end #page-wrap -->

</body>
</html>
