var whereIsMouse = "icon";

function init() {
    document.getElementById("icon").addEventListener("mouseover", function(){
		iconMouseover("0.5");
    });
    
    document.getElementById("cart").addEventListener("mouseover", function(){
		cartMouseover("0.5");
    });
    
    var menuItems = document.getElementsByClassName("menu-item");
    for (let i=0; i < menuItems.length; i++) {
 		menuItems[i].addEventListener("mouseover", function() {
 	    	menuItemMouseover(i, "0.5");
 		});
    }
    
    if ( sessionStorage.shoppingList) {
	   	var obj = JSON.parse(sessionStorage.getItem("shoppingList"));
	   	document.getElementById("cart").innerHTML = obj.length;
    }

 

    window.addEventListener("resize", function() {
     	if (whereIsMouse == "cart")  {
    		cartMouseover("0");
    	}
    	else if (whereIsMouse == "icon" )  {
	    	iconMouseover("0");
    	}
    	else {
    	    menuItemMouseover(parseInt( whereIsMouse[4] ), "0")
    	}
    });
}


 function fetchShoppingList() {
	var lis;
	if ( sessionStorage.shoppingList)  {
 		lis = JSON.parse(sessionStorage.getItem("shoppingList"));
 	}
 	else {
 		lis = [];
 	} 
	return lis;		 			
 }
 

function iconMouseover(v) {
	var line = document.getElementById("underline");
	line.style.transition = "left " + v + "s"
	line.style.width = (160 + "px");
	line.style.left = 0 + "px";
	whereIsMouse = "icon";
}


function cartMouseover(v) {
	var pageWrapWidth = document.getElementById("page-wrap").offsetWidth;
	var line = document.getElementById("underline");
	line.style.transition = "left " + v + "s"
	line.style.width = 68 + "px"; /*38 px for the width of the icon, 20 px for padding on the right, 10 for padding on the left*/
	line.style.left = (pageWrapWidth - 78) + "px"; 
	whereIsMouse = "cart";
	document.getElementById("underlineLoc").innerHTML = whereIsMouse;
}


function menuItemMouseover(ind,v) {
	var pageWrapWidth = document.getElementById("page-wrap").offsetWidth;
	var line = document.getElementById("underline");
	line.style.transition = "left " + v + "s"
	whereIsMouse = "item" + ind;
	line.style.width = 74 + "px";
	line.style.left = (pageWrapWidth - 78) - (74 * ( 1 + ind) ) + "px";
}

function addToShoppingList(item) { 
	var list = JSON.parse(sessionStorage.getItem("shoppingList"));

	if ( list == null ) {
		list = [];
	}
	list.push( item );
	
	var len = list.length;
	if ( len ==0 )  {
		document.getElementById("cart").innerHTML = "";
	}
	else {
		document.getElementById("cart").innerHTML = len;
	}
	sessionStorage.setItem("shoppingList", JSON.stringify(list) );
	document.getElementById("stuffIbought").innerHTML += item.itemDescription;
}

function checkout(){
	var name = document.getElementById("name").value;
	var streetAddress = document.getElementById("st_Add").value;
	var cityPostalCode = document.getElementById("PosCode").value;
	var provinceTerritory = document.getElementById("province").value;
	var email = document.getElementById("email").value;
	var creditCardNumber = document.getElementById("cardNum").value;
	var shoppingList = JSON.stringify(fetchShoppingList());
	  var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
            		sessionStorage.setItem("shoppingList", null);
					location.reload();
            }
        };
        xmlhttp.open("POST", "scripts/customer_transaction.php?name="+name + "&streetAddress="+streetAddress + "&cityPostalCode="+cityPostalCode + "&provinceTerritory="+provinceTerritory + "&email="+email + "&creditCardNumber="+creditCardNumber + "&products="+shoppingList, true);
        xmlhttp.send();
}

function getNameInfo(){
	var name = document.getElementById("name").value;
	console.log(name);
	var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
    	if (this.readyState == 4 && this.status == 200) {
    		if(this.responseText != "None"){
    			var ret = JSON.parse(this.responseText)[0];
					document.getElementById("st_Add").value = ret[0];
					document.getElementById("PosCode").value= ret[1];
					document.getElementById("province").value= ret[2];
					document.getElementById("email").value= ret[3];
					document.getElementById("cardNum").value= ret[4];
    		}
    	}
    };
    xmlhttp.open("POST", "scripts/get_customer.php?name="+name, true);
    xmlhttp.send();
	
}