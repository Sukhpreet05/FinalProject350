<?php

    $host = getenv("IP");
    $user = getenv("C9_USER");
    $pass = "";            
    $db = "Products";                            
    $port = 3306;
    $database = mysqli_connect($host, $user, $pass, $db, $port) or die(mysql_error());
    $name = $_REQUEST['name'];
    // Make name primar ykey
    $strAddress = $_REQUEST['streetAddress'];
    if ($strAddress == ""){
        $strAddress = "Not Known";
    }
    $ctPostalCode = $_REQUEST['cityPostalCode'];
    $provTerritory = $_REQUEST['provinceTerritory'];
    $email = $_REQUEST['email'];
    $creditCardNumber = $_REQUEST['creditCardNumber'];
    
    $products = json_decode($_REQUEST['products'], true);


    $s = "";
    $start = 0;

    foreach($products as $product) {
        if($start == 0){
            $pname = $product["itemDescription"];
            $pprice = $product["itemPrice"];
            $da = date("y-m-d");
            $s .= "('$name', '$pname','$da','$pprice' )";
            $start = 1;
         
        }
        else{
            $pname = $product["itemDescription"];
            $pprice = $product["itemPrice"];
            $da = date("y-m-d");
            $s .= ",('$name', '$pname','$da','$pprice' )";
        }
    }
    

 $start = $database->query("insert into Customers values('$strAddress','$ctPostalCode','$provTerritory','$email','$creditCardNumber','$name');");
//  echo  "insert into Transactions values " . $s;
//  echo "insert into Transactions values " + $s +";"

 $start += $database->query("insert into Transactions values " . $s .";");
 echo $start;
    
?>
    