<?php

    $host = getenv("IP");
    $user = getenv("C9_USER");
    $pass = "";            
    $db = "Products";                            
    $port = 3306;
    $database = mysqli_connect($host, $user, $pass, $db, $port) or die(mysql_error());
    
    $man = $_REQUEST['manufacturer'];
    if ($man != ""){
    
    $query = $database->query("select imageLocation as 'itemImageSrc' , 'placeholder' as 'itemImageAlt', productName as 'itemDescription', price as 'itemPrice'  from Products where category = 'Popular Items' and manufacturer = '$man' limit 6;");
    $arr_st_pi = array();
    while($rows = $query->fetch_assoc()){
        $arr_st_pi[] = $rows;
    }
    
    $query = $database->query("select imageLocation as 'itemImageSrc' , 'placeholder' as 'itemImageAlt', productName as 'itemDescription', price as 'itemPrice'  from Products where category = 'Strawberry Pi' and manufacturer = '$man' limit 6;");
    $ar_st_pi_as = array();
    while($rows = $query->fetch_assoc()){
            $ar_st_pi_as[] = $rows;
    }
    

    $query = $database->query("select imageLocation as 'itemImageSrc' , 'placeholder' as 'itemImageAlt', productName as 'itemDescription', price as 'itemPrice'  from Products where category = 'Strawberry Pi Accessories' and manufacturer = '$man' limit 6;");
    $Pop_items = array();
    while ($rows = $query->fetch_assoc()){
        $Pop_items[] = $rows;
    }
    
    
    $query = $database->query("select imageLocation as 'itemImageSrc' , 'placeholder' as 'itemImageAlt', productName as 'itemDescription', price as 'itemPrice'  from Products where category = 'Industrial Compute Model' and manufacturer = '$man' limit 6;");
    $Ind_Comp_Mod = array();
    while($rows = $query->fetch_assoc()){
        $Ind_Comp_Mod[] = $rows;
    }
    
    $cata = array(
        "Strawberry Pi" => $arr_st_pi,
        "Strawberry Pi Accessories" => $ar_st_pi_as,
        "Popular Items" => $Pop_items,
        "Industrial Compute Model" => $Ind_Comp_Mod
        );
    
    $json_data = json_encode($cata);
    
    
    $query = $database->query("SELECT DISTINCT(manufacturer) FROM Products;");
    $manfact_items = array();
    while ($rows = $query->fetch_all()){
        $manfact_items[] = $rows;
    }
    
    $json_manuf_data = json_encode($manfact_items);
    
    
    echo $json_data;

}
    
    
    
?>