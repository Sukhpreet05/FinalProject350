<?php

    $host = getenv("IP");
    $user = getenv("C9_USER");
    $pass = "";            
    $db = "Products";                            
    $port = 3306;
    $database = mysqli_connect($host, $user, $pass, $db, $port) or die(mysql_error());
    $man = $_REQUEST['name'];
    if($man != ""){
    $query = $database->query("select * from Customers where name = '$man'");
    $result = $query->fetch_all();
    if(count($result) == 0){
        echo "None";
    }
    else{
        echo json_encode($result);
    }
    }
?>
    