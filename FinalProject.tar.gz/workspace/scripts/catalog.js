//alert("in catalog");
// temporary javascript version before learning mockbin
/*     var catalog = 
         { "Popular Items": [
               {
                   "itemImageSrc" : "./images/Strawberry_Pi_3_Model_B.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "Strawberry Pi 3 Model B",
                   "itemPrice" : "49.95"
              },
               {
                   "itemImageSrc" : "./images/Strawberry_Pi_Zero.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "Strawberry Pi Zero",
                   "itemPrice" : "29.95"
               },
               {
                   "itemImageSrc" : "./images/Strawberry_Pi_Case.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "Strawberry Pi Case",
                   "itemPrice" : "10.95"
               },
               {
                   "itemImageSrc" : "./images/Compute_Module.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "Compute Module",
                   "itemPrice" : "149.95"
               }
          ],
		 "Strawberry Pi": [
               {
                   "itemImageSrc" : "./images/Strawberry_Pi_3_Model_B.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "Strawberry Pi 3 Model B",
                   "itemPrice" : "49.95"
               },
               {
                   "itemImageSrc" : "./images/Strawberry_Pi_Zero.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : " Strawberry Pi Zero ",
                   "itemPrice" : "29.95"
               },
               {
                   "itemImageSrc" : "./images/Strawberry_Pi_Case.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "Strawberry Pi Case",
                   "itemPrice" : "10.95"
              },
               {
                   "itemImageSrc" : "./images/Camera_Module_V2.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "Strawberry Pi Extension Kit",
                   "itemPrice" : "149.95"
               }
          ],
   		 "Strawberry Pi Acessories": [
          {
               "itemImageSrc" : "./images/Camera_Module_V2.jpg",
                "itemImageAlt" : "placeholder",
                   "itemDescription" : "Camera Module Version 2",
                   "itemPrice" : "49.95"
               },
               {
                   "itemImageSrc" : "./images/Strawberry_Pi_Zero.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "Strawberry Pi Zero",
                   "itemPrice" : "29.95"
               },
               {
                   "itemImageSrc" : "./images/placeholder.png",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : " Strawberry Pi Case ",
                   "itemPrice" : "10.95"
              },
               {
                   "itemImageSrc" : "./images/placeholder.png",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : " Strawberry Pi Extension Kit ",
                   "itemPrice" : "149.95"
               }
          ],
      "Industrial Compute Model": [
          {
               "itemImageSrc" : "./images/Strawberry_Pi_3_Model_B.jpg",
                "itemImageAlt" : "placeholder",
                   "itemDescription" : "Strawberry Pi 3 Model B",
                   "itemPrice" : "49.95"
               },
               {
                   "itemImageSrc" : "./images/Strawberry_Pi_Zero.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : " Strawberry Pi Zero ",
                   "itemPrice" : "29.95"
               },
               {
                   "itemImageSrc" : "./images/Compute_Model_Kit.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "Compute Module Kit",
                   "itemPrice" : "10.95"
              },
              {
                   "itemImageSrc" : "./images/Compute_Module.jpg",
                   "itemImageAlt" : "placeholder",
                   "itemDescription" : "Original Computer Module",
                   "itemPrice" : "149.95"
               }
          ]
	 };
*/

var catalog;

function fetchCatalog() {	
	var xmlhttp = new XMLHttpRequest();
	var url = "https://mockbin.org/bin/382af243-4a26-414a-b57d-ff1d50d8330a";    //bc8ed2d5-1d54-42ca-a910-cfe9ded06d26"; //"https://mockbin.org/bin/b1307535-2860-4f1d-9193-924db2db7a46";
	xmlhttp.onreadystatechange = function() {
 
    	if (this.readyState == 4 && this.status == 200) {
			catalog = JSON.parse( this.responseText.slice(0,-1) );
		}
	};
	
	xmlhttp.open("GET", url, false);
	xmlhttp.send();
}

fetchCatalog();


