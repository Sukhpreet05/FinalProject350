
var x;

// Begin features

function createCatalog() {
	


var doc = document.createElement("div");
doc.id = "catalog";
var code=( '<div class="feature">' );





// Note that for my personal solution, I am maintaining a separate list of popular items
// and a separate list of all the other items. You may have done things a little differently

for (x in catalog ) {
	if ( x !== "Popular Items")  {
		///Build the header
		code+=( '<div class=feature-text>');
		code+=( x );
		code+=( '</div>');
		
		// build feature container
		code+=( '<div class="feature-container">' );
		var currentItems = catalog[x];
		for ( var i = 0; i < currentItems.length; i++) {
			code+=('<div class="feature-box">');
			code+=('<img src="');
			code+=(currentItems[i].itemImageSrc);
			code+=('" alt="');
        	code+=(currentItems[i].itemImageAlt);
			code+=('">');

			code+=('<div class="feature-box-model">');
			code+=(currentItems[i].itemDescription);
			code+=('</div>');

			code+=('<div class="feature-box-price">');
			code+=(currentItems[i].itemPrice);
			code+=('</div>');
			
			// I construct a unique id for each item with the prefix
			// add-to-Cart, it's category (which forms a title) and a unique integer
			
			var id = "addToCart" + x + i;
			code+=("<button id='"); 
			code+=( id + "' type='button' onclick=" + '"addShoppingList' + "('" + x + "','"+i+"')"+'">Add to Cart</button><BR>');
			let c = currentItems[i];
			//document.getElementById( id ).addEventListener("click", function(){addToShoppingList(c)});
			code+=('</div>');

		}
		
            code+=( '<div class="feature">' );
		
		
	        code+=('<div class="clearboth"></div>');
		
	}
	
  }
  doc.innerHTML = code;
  document.getElementById("cata").appendChild(doc);
  
}



createCatalog();

console.log(manufacturer);
for (x in manufacturer ) {
	
let list = document.getElementById("myDropdown");
let element = document.createElement("a");
element.innerHTML = manufacturer[x];
element.onclick = function(){
	
	
	  var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
            		catalog = JSON.parse(this.responseText);
            		console.log(this.responseText);
            		removeCatalog();
					createCatalog();
            }
        };
        xmlhttp.open("GET", "scripts/product_by_manufacture.php?manufacturer="+this.innerHTML, true);
        xmlhttp.send();
	
	
};

function removeCatalog() {
	
	var rmItems = document.getElementById("catalog");
	rmItems.parentNode.removeChild(rmItems);
}



list.appendChild(element);

}


function addShoppingList(x, i){


addToShoppingList(catalog[x][i]);
	
}